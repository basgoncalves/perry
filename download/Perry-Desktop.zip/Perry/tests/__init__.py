"""
Perry's test suite.

Run it from the terminal:

    python . --tests

...or click TESTS on the HUD to watch it run inside the app.

None of these tests need a microphone, a network connection or a real desktop
session — audio is synthesised in memory and Perry's collaborators are
injected as fakes (see tests/fakes.py). That's deliberate: a suite you can run
in two seconds, on a laptop with no mic plugged in, is a suite you'll actually
run.
"""
