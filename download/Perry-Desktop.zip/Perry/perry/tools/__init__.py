"""
Standalone diagnostics for Perry's ears.

    python . --mics     which microphone actually hears you
    python . --meter    live clap level meter, for tuning config.json
"""
